import{e as S,s as O}from"./profile-41mQexTl.js";import{P as b,g as h}from"./settings-Clqb1TkW.js";const A="career-copilot",R=1,c="kv";let u=null;function E(){return u||(u=new Promise((e,r)=>{const n=indexedDB.open(A,R);n.onupgradeneeded=()=>{const t=n.result;t.objectStoreNames.contains(c)||t.createObjectStore(c)},n.onsuccess=()=>e(n.result),n.onerror=()=>r(n.error)}),u)}async function U(e){const r=await E();return new Promise((n,t)=>{const o=r.transaction(c,"readonly").objectStore(c).get(e);o.onsuccess=()=>n(o.result),o.onerror=()=>t(o.error)})}async function _(e,r){const n=await E();return new Promise((t,s)=>{const o=n.transaction(c,"readwrite");o.objectStore(c).put(r,e),o.oncomplete=()=>t(),o.onerror=()=>s(o.error)})}const x="profile";async function p(){return await U(x)??S()}async function v(e){await _(x,{...e,updatedAt:Date.now()})}async function f(e,r){var t;if(!e.apiKey)throw new Error("未配置 API Key，请在设置中填写");if(!e.baseUrl)throw new Error("未配置 Base URL，请在设置中填写");return(((t=b[e.provider])==null?void 0:t.format)??"openai")==="anthropic"?I(e,r):N(e,r)}async function I(e,r){const n=e.baseUrl.replace(/\/$/,""),t={model:e.model,max_tokens:r.maxTokens??4096,messages:r.messages.map(a=>({role:a.role,content:a.content}))};r.system&&(t.system=r.system);const s=await fetch(`${n}/v1/messages`,{method:"POST",headers:{"content-type":"application/json","x-api-key":e.apiKey,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify(t)});if(!s.ok){const a=await s.text();throw new Error(`Claude API 错误 ${s.status}: ${a.slice(0,300)}`)}return{text:((await s.json()).content??[]).filter(a=>a.type==="text").map(a=>a.text).join(`
`)}}async function N(e,r){var g,m,d;const n=e.baseUrl.replace(/\/$/,""),t=[];r.system&&t.push({role:"system",content:r.system});for(const l of r.messages)t.push({role:l.role,content:l.content});const s={model:e.model,max_tokens:r.maxTokens??4096,messages:t};r.json&&(s.response_format={type:"json_object"});const o=await fetch(`${n}/v1/chat/completions`,{method:"POST",headers:{"content-type":"application/json",authorization:`Bearer ${e.apiKey}`},body:JSON.stringify(s)});if(!o.ok){const l=await o.text();throw new Error(`OpenAI API 错误 ${o.status}: ${l.slice(0,300)}`)}return{text:((d=(m=(g=(await o.json()).choices)==null?void 0:g[0])==null?void 0:m.message)==null?void 0:d.content)??""}}function k(e){let r=e.trim();const n=r.match(/```(?:json)?\s*([\s\S]*?)```/i);n&&(r=n[1].trim());const t=r.indexOf("{"),s=r.lastIndexOf("}");return t>=0&&s>t&&(r=r.slice(t,s+1)),JSON.parse(r)}function $(e){var r;return(((r=b[e.provider])==null?void 0:r.format)??"openai")==="openai"}function L(e){const r=e.match(/<title[^>]*>([\s\S]*?)<\/title>/i),n=r?w(y(r[1])).trim():"";let t=e;return t=t.replace(/<script[\s\S]*?<\/script>/gi," "),t=t.replace(/<style[\s\S]*?<\/style>/gi," "),t=t.replace(/<noscript[\s\S]*?<\/noscript>/gi," "),t=t.replace(/<!--[\s\S]*?-->/g," "),t=t.replace(/<(nav|footer|header|svg|head)[\s\S]*?<\/\1>/gi," "),t=t.replace(/<\/(p|div|li|tr|h[1-6]|section|article|br)>/gi,`
`),t=t.replace(/<br\s*\/?>/gi,`
`),t=y(t),t=w(t),t=t.replace(/[ \t]{2,}/g," ").replace(/\n{3,}/g,`

`).trim(),{title:n,text:t.slice(0,2e4)}}function y(e){return e.replace(/<[^>]+>/g," ")}function w(e){return e.replace(/&nbsp;/g," ").replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&#(\d+);/g,(r,n)=>String.fromCharCode(Number(n)))}async function J(e){let r;try{r=new URL(e)}catch{throw new Error("链接格式不正确，请填写完整网址（含 http/https）")}if(r.protocol!=="http:"&&r.protocol!=="https:")throw new Error("只支持 http/https 链接");let n;try{n=await fetch(r.toString(),{redirect:"follow"})}catch(i){throw new Error("抓取失败："+String(i.message??i)+"。该网站可能禁止跨站抓取，可改用「粘贴文本」。")}if(!n.ok)throw new Error(`抓取失败，HTTP ${n.status}`);const t=await n.text(),{title:s,text:o}=L(t);if(o.length<40)throw new Error("抓到的正文过少（可能是需要登录或 JS 动态渲染的页面）。可改用「粘贴文本」。 也可以先在浏览器标签页打开该网址，再重新点击读取。");return{url:r.toString(),title:s,text:o}}function T(e){return e==="zh"?"请用中文输出。":e==="en"?"Respond in English.":"根据页面/简历主要语言选择中文或英文输出（中文内容用中文，英文内容用英文）。"}const D=`你是一个信息抽取引擎。你会收到一份简历或个人主页的纯文本，需要把它抽取成严格的 JSON。
只输出 JSON，不要任何解释文字。JSON 必须符合以下 TypeScript 结构（字段缺失就省略或给空数组，不要编造）：

{
  "basic": { "name","nameEn","email","phone","gender","birthday","location","wechat","github","linkedin","homepage","portfolio" },
  "education": [ { "id","school","schoolEn","degree","major","majorEn","gpa","startDate","endDate","city","description","courses":[] } ],
  "experiences": [ { "id","type":"internship|work|project|research","organization","organizationEn","role","roleEn","startDate","endDate","city","highlights":[],"highlightsEn":[],"tech":[],"link" } ],
  "publications": [ { "id","title","authors","venue","year","link","note" } ],
  "skills": [ { "id","category","items":[] } ],
  "languages": [ { "id","language","level" } ],
  "summaries": [ { "id","label","zh","en" } ]
}

规则：
- 每个数组项的 id 用短随机字符串（如 "e1","x1"）。
- experiences 里实习=internship，正式工作=work，课程/个人项目=project，科研经历=research。
- 尽量保留原文要点，highlights 每条是一句话。
- 若原文是中文，highlights 填 highlights；若是英文，填 highlightsEn。`;function C(e){return`以下是简历/主页文本，请抽取为 JSON：

"""
${e.slice(0,2e4)}
"""`}function P(e){const r=[];(e.basic.name||e.basic.nameEn)&&r.push(`姓名: ${e.basic.name??""} ${e.basic.nameEn??""}`);for(const t of e.education)r.push(`教育: ${t.school??""} ${t.degree??""} ${t.major??""} (${t.startDate??""}-${t.endDate??""})`);for(const t of e.experiences){const s=[...t.highlights??[],...t.highlightsEn??[]].slice(0,4).join("; ");r.push(`${t.type}: ${t.organization??t.organizationEn??""} - ${t.role??t.roleEn??""} | ${s}`)}for(const t of e.publications)r.push(`论文: ${t.title??""} (${t.venue??""} ${t.year??""})`);const n=e.skills.map(t=>`${t.category??""}: ${(t.items??[]).join("/")}`).join(" | ");return n&&r.push(`技能: ${n}`),r.join(`
`).slice(0,6e3)}function z(e){return`你是资深求职顾问。基于用户的背景和岗位 JD，给出可执行的匹配与优化建议。${T(e.outputLang)}
只输出 JSON，结构如下（不要多余文字）：
{
  "kind": "jd",
  "summary": "对岗位的一句话理解",
  "matchPoints": ["用户已具备、与岗位契合的点"],
  "gaps": ["明显差距"],
  "optimizations": [ { "area":"简历某部分/某段经历", "advice":"如何优化", "revisedText":"可选，改写后的文案" } ],
  "howToMatch": ["为了更 match 可以做的具体动作：补充哪些项目/研究、从哪些方向切入"]
}`}function K(e,r){return`【我的背景】
${P(e)}

【岗位 JD】
${r.slice(0,8e3)}`}function M(e){return`你是科研申请顾问，帮助学生联系教授（套词）、申请 RA/研究生。基于教授主页信息和用户背景给建议。${T(e.outputLang)}
只输出 JSON，结构如下（不要多余文字）：
{
  "kind": "professor",
  "researchFocus": ["教授的研究方向/兴趣点"],
  "commonGround": ["与用户背景的共同点/可衔接处"],
  "approachAngles": ["套词切入角度"],
  "collaboration": ["后续可行的合作方向：基于用户已有内容能做什么、如何展开"],
  "emailDraft": { "subject": "邮件标题", "body": "可直接发送的套词邮件正文，含称呼与署名占位" }
}`}function q(e,r){return`【我的背景】
${P(e)}

【教授主页/研究信息】
${r.slice(0,8e3)}`}chrome.runtime.onInstalled.addListener(()=>{var e,r;(r=(e=chrome.sidePanel)==null?void 0:e.setPanelBehavior)==null||r.call(e,{openPanelOnActionClick:!1}).catch(()=>{})});chrome.runtime.onMessage.addListener((e,r,n)=>(B(e).then(t=>n(t)).catch(t=>n({ok:!1,error:String((t==null?void 0:t.message)??t)})),!0));async function B(e){switch(e.type){case"GET_PROFILE":return p();case"SAVE_PROFILE":return await v(e.profile),{ok:!0};case"TEST_LLM":return G();case"STRUCTURE_TEXT":return j(e.text,e.mergeInto??!1);case"STRUCTURE_URL":return F(e.url,e.mergeInto??!1);case"ANALYZE_PAGE":return Y(e.page.kind,e.page.text);case"QUEUE_ANALYSIS":return await chrome.storage.local.set({currentAnalysis:{status:"pending",page:e.page,requestId:e.requestId}}),{ok:!0};default:return{ok:!1,error:`未知消息: ${e.type}`}}}async function G(){try{const e=await h();return(await f(e,{messages:[{role:"user",content:"回复 OK 两个字符即可。"}],maxTokens:16})).text?{ok:!0}:{ok:!1,error:"模型无返回"}}catch(e){return{ok:!1,error:String(e.message??e)}}}async function j(e,r){try{const n=await h(),t=await f(n,{system:D,messages:[{role:"user",content:C(e)}],json:$(n),maxTokens:8192}),s=k(t.text),o=r?await p():S();return{ok:!0,profile:V(o,s)}}catch(n){return{ok:!1,error:String(n.message??n)}}}async function F(e,r){try{let n;try{n=new URL(e)}catch{throw new Error("链接格式不正确，请填写完整网址（含 http/https）")}if(n.protocol!=="http:"&&n.protocol!=="https:")throw new Error("只支持 http/https 链接");const s=(await chrome.tabs.query({})).find(i=>{try{const a=new URL(i.url??"");return a.origin===n.origin&&a.pathname===n.pathname&&a.search===n.search}catch{return!1}});let o;if(s)try{o=(await O(s,{type:"SCAN_PAGE"})).text}catch{}return o||(o=(await J(e)).text),j(o,r)}catch(n){return{ok:!1,error:String(n.message??n)}}}function V(e,r){const n=JSON.parse(JSON.stringify(e));if(r.basic)for(const[s,o]of Object.entries(r.basic))o&&(n.basic[s]=o);const t=["education","experiences","publications","skills","languages","summaries"];for(const s of t){const o=r[s]??[];o.length&&(n[s]=[...n[s],...o])}return n.updatedAt=0,n}async function Y(e,r){try{const n=await h(),t=await p(),s=e==="professor",o=await f(n,{system:s?M(n):z(n),messages:[{role:"user",content:s?q(t,r):K(t,r)}],json:$(n),maxTokens:4096});return{ok:!0,suggestion:k(o.text)}}catch(n){return{ok:!1,error:String(n.message??n)}}}
