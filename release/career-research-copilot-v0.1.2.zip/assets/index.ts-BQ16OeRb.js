import{e as d,s as _}from"./profile-BdGqdjx1.js";import{P as x,g as y}from"./settings-Clqb1TkW.js";const U="career-copilot",v=1,l="kv";let f=null;function k(){return f||(f=new Promise((e,r)=>{const n=indexedDB.open(U,v);n.onupgradeneeded=()=>{const t=n.result;t.objectStoreNames.contains(l)||t.createObjectStore(l)},n.onsuccess=()=>e(n.result),n.onerror=()=>r(n.error)}),f)}async function L(e){const r=await k();return new Promise((n,t)=>{const s=r.transaction(l,"readonly").objectStore(l).get(e);s.onsuccess=()=>n(s.result),s.onerror=()=>t(s.error)})}const g="profile",I="rawResumeText";async function A(){return await L(g)??d()}async function T(e,r,n){const t=await k();return new Promise((o,s)=>{const a=t.transaction(l,"readwrite"),i=a.objectStore(l);let c;const u=i.get(g);u.onsuccess=()=>{const p=u.result??d();if(p.updatedAt!==r){s(new Error("个人数据已在其他窗口更新，请刷新后重试，避免混合不同求职人的信息。")),a.abort();return}c={...e,updatedAt:Math.max(Date.now(),p.updatedAt+1)},i.put(c,g),n&&i.delete(I)},a.oncomplete=()=>o(c),a.onerror=()=>s(a.error),a.onabort=()=>s(a.error)})}function N(e){return T(e,e.updatedAt,!1)}function D(e,r){return T(e,r,!0)}async function w(e,r){var t;if(!e.apiKey)throw new Error("未配置 API Key，请在设置中填写");if(!e.baseUrl)throw new Error("未配置 Base URL，请在设置中填写");return(((t=x[e.provider])==null?void 0:t.format)??"openai")==="anthropic"?J(e,r):C(e,r)}async function J(e,r){const n=e.baseUrl.replace(/\/$/,""),t={model:e.model,max_tokens:r.maxTokens??4096,messages:r.messages.map(i=>({role:i.role,content:i.content}))};r.system&&(t.system=r.system);const o=await fetch(`${n}/v1/messages`,{method:"POST",headers:{"content-type":"application/json","x-api-key":e.apiKey,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify(t)});if(!o.ok){const i=await o.text();throw new Error(`Claude API 错误 ${o.status}: ${i.slice(0,300)}`)}return{text:((await o.json()).content??[]).filter(i=>i.type==="text").map(i=>i.text).join(`
`)}}async function C(e,r){var c,u,p;const n=e.baseUrl.replace(/\/$/,""),t=[];r.system&&t.push({role:"system",content:r.system});for(const h of r.messages)t.push({role:h.role,content:h.content});const o={model:e.model,max_tokens:r.maxTokens??4096,messages:t};r.json&&(o.response_format={type:"json_object"});const s=await fetch(`${n}/v1/chat/completions`,{method:"POST",headers:{"content-type":"application/json",authorization:`Bearer ${e.apiKey}`},body:JSON.stringify(o)});if(!s.ok){const h=await s.text();throw new Error(`OpenAI API 错误 ${s.status}: ${h.slice(0,300)}`)}return{text:((p=(u=(c=(await s.json()).choices)==null?void 0:c[0])==null?void 0:u.message)==null?void 0:p.content)??""}}function P(e){let r=e.trim();const n=r.match(/```(?:json)?\s*([\s\S]*?)```/i);n&&(r=n[1].trim());const t=r.indexOf("{"),o=r.lastIndexOf("}");return t>=0&&o>t&&(r=r.slice(t,o+1)),JSON.parse(r)}function $(e){var r;return(((r=x[e.provider])==null?void 0:r.format)??"openai")==="openai"}function M(e){const r=e.match(/<title[^>]*>([\s\S]*?)<\/title>/i),n=r?S(E(r[1])).trim():"";let t=e;return t=t.replace(/<script[\s\S]*?<\/script>/gi," "),t=t.replace(/<style[\s\S]*?<\/style>/gi," "),t=t.replace(/<noscript[\s\S]*?<\/noscript>/gi," "),t=t.replace(/<!--[\s\S]*?-->/g," "),t=t.replace(/<(nav|footer|header|svg|head)[\s\S]*?<\/\1>/gi," "),t=t.replace(/<\/(p|div|li|tr|h[1-6]|section|article|br)>/gi,`
`),t=t.replace(/<br\s*\/?>/gi,`
`),t=E(t),t=S(t),t=t.replace(/[ \t]{2,}/g," ").replace(/\n{3,}/g,`

`).trim(),{title:n,text:t.slice(0,2e4)}}function E(e){return e.replace(/<[^>]+>/g," ")}function S(e){return e.replace(/&nbsp;/g," ").replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&#(\d+);/g,(r,n)=>String.fromCharCode(Number(n)))}async function z(e){let r;try{r=new URL(e)}catch{throw new Error("链接格式不正确，请填写完整网址（含 http/https）")}if(r.protocol!=="http:"&&r.protocol!=="https:")throw new Error("只支持 http/https 链接");let n;try{n=await fetch(r.toString(),{redirect:"follow"})}catch(a){throw new Error("抓取失败："+String(a.message??a)+"。该网站可能禁止跨站抓取，可改用「粘贴文本」。")}if(!n.ok)throw new Error(`抓取失败，HTTP ${n.status}`);const t=await n.text(),{title:o,text:s}=M(t);if(s.length<40)throw new Error("抓到的正文过少（可能是需要登录或 JS 动态渲染的页面）。可改用「粘贴文本」。 也可以先在浏览器标签页打开该网址，再重新点击读取。");return{url:r.toString(),title:o,text:s}}function R(e){return e==="zh"?"请用中文输出。":e==="en"?"Respond in English.":"根据页面/简历主要语言选择中文或英文输出（中文内容用中文，英文内容用英文）。"}const K=`你是一个信息抽取引擎。你会收到一份简历或个人主页的纯文本，需要把它抽取成严格的 JSON。
只输出 JSON，不要任何解释文字。JSON 必须符合以下 TypeScript 结构（字段缺失就省略或给空数组，不要编造）：

{
  "basic": { "name","nameEn","email","phone","gender","birthday","location","wechat","github","linkedin","homepage","portfolio" },
  "education": [ { "id","school","schoolEn","degree","major","majorEn","gpa","startDate","endDate","city","description","courses":[] } ],
  "experiences": [ { "id","type":"internship|work|project|research","organization","organizationEn","role","roleEn","startDate","endDate","city","highlights":[],"highlightsEn":[],"tech":[],"link" } ],
  "publications": [ { "id","title","authors","venue","year","link","note" } ],
  "skills": [ { "id","category","items":[] } ],
  "languages": [ { "id","language","level" } ],
  "summaries": [ { "id","label","zh","en" } ]
}

规则：
- 每个数组项的 id 用短随机字符串（如 "e1","x1"）。
- experiences 里实习=internship，正式工作=work，课程/个人项目=project，科研经历=research。
- 尽量保留原文要点，highlights 每条是一句话。
- 若原文是中文，highlights 填 highlights；若是英文，填 highlightsEn。`;function q(e){return`以下是简历/主页文本，请抽取为 JSON：

"""
${e.slice(0,2e4)}
"""`}function j(e){const r=[];(e.basic.name||e.basic.nameEn)&&r.push(`姓名: ${e.basic.name??""} ${e.basic.nameEn??""}`);for(const t of e.education)r.push(`教育: ${t.school??""} ${t.degree??""} ${t.major??""} (${t.startDate??""}-${t.endDate??""})`);for(const t of e.experiences){const o=[...t.highlights??[],...t.highlightsEn??[]].slice(0,4).join("; ");r.push(`${t.type}: ${t.organization??t.organizationEn??""} - ${t.role??t.roleEn??""} | ${o}`)}for(const t of e.publications)r.push(`论文: ${t.title??""} (${t.venue??""} ${t.year??""})`);const n=e.skills.map(t=>`${t.category??""}: ${(t.items??[]).join("/")}`).join(" | ");return n&&r.push(`技能: ${n}`),r.join(`
`).slice(0,6e3)}function B(e){return`你是资深求职顾问。基于用户的背景和岗位 JD，给出可执行的匹配与优化建议。${R(e.outputLang)}
只输出 JSON，结构如下（不要多余文字）：
{
  "kind": "jd",
  "summary": "对岗位的一句话理解",
  "matchPoints": ["用户已具备、与岗位契合的点"],
  "gaps": ["明显差距"],
  "optimizations": [ { "area":"简历某部分/某段经历", "advice":"如何优化", "revisedText":"可选，改写后的文案" } ],
  "howToMatch": ["为了更 match 可以做的具体动作：补充哪些项目/研究、从哪些方向切入"]
}`}function F(e,r){return`【我的背景】
${j(e)}

【岗位 JD】
${r.slice(0,8e3)}`}function G(e){return`你是科研申请顾问，帮助学生联系教授（套词）、申请 RA/研究生。基于教授主页信息和用户背景给建议。${R(e.outputLang)}
只输出 JSON，结构如下（不要多余文字）：
{
  "kind": "professor",
  "researchFocus": ["教授的研究方向/兴趣点"],
  "commonGround": ["与用户背景的共同点/可衔接处"],
  "approachAngles": ["套词切入角度"],
  "collaboration": ["后续可行的合作方向：基于用户已有内容能做什么、如何展开"],
  "emailDraft": { "subject": "邮件标题", "body": "可直接发送的套词邮件正文，含称呼与署名占位" }
}`}function V(e,r){return`【我的背景】
${j(e)}

【教授主页/研究信息】
${r.slice(0,8e3)}`}chrome.runtime.onInstalled.addListener(()=>{var e,r;(r=(e=chrome.sidePanel)==null?void 0:e.setPanelBehavior)==null||r.call(e,{openPanelOnActionClick:!1}).catch(()=>{})});chrome.runtime.onMessage.addListener((e,r,n)=>(Y(e).then(t=>n(t)).catch(t=>n({ok:!1,error:String((t==null?void 0:t.message)??t)})),!0));async function Y(e){switch(e.type){case"GET_PROFILE":return A();case"SAVE_PROFILE":return m(await N(e.profile));case"REPLACE_PROFILE":return m(await b(e.profile,e.expectedUpdatedAt));case"CLEAR_PERSONAL_DATA":return m(await b(d(),e.expectedUpdatedAt));case"TEST_LLM":return H();case"STRUCTURE_TEXT":return O(e.text);case"STRUCTURE_URL":return Q(e.url);case"ANALYZE_PAGE":return X(e.page.kind,e.page.text);case"QUEUE_ANALYSIS":return await chrome.storage.local.set({currentAnalysis:{status:"pending",page:e.page,requestId:e.requestId}}),{ok:!0};default:return{ok:!1,error:`未知消息: ${e.type}`}}}async function m(e){return await chrome.storage.local.set({profileRevision:e.updatedAt}),{ok:!0,profile:e}}async function b(e,r){const n=await D(e,r);return await chrome.storage.local.remove(["fieldMappings","currentAnalysis"]),n}async function H(){try{const e=await y();return(await w(e,{messages:[{role:"user",content:"回复 OK 两个字符即可。"}],maxTokens:16})).text?{ok:!0}:{ok:!1,error:"模型无返回"}}catch(e){return{ok:!1,error:String(e.message??e)}}}async function O(e){try{const r=await y(),n=await w(r,{system:K,messages:[{role:"user",content:q(e)}],json:$(r),maxTokens:8192}),t=P(n.text);return{ok:!0,profile:W(t)}}catch(r){return{ok:!1,error:String(r.message??r)}}}async function Q(e){try{let r;try{r=new URL(e)}catch{throw new Error("链接格式不正确，请填写完整网址（含 http/https）")}if(r.protocol!=="http:"&&r.protocol!=="https:")throw new Error("只支持 http/https 链接");const t=(await chrome.tabs.query({})).find(s=>{try{const a=new URL(s.url??"");return a.origin===r.origin&&a.pathname===r.pathname&&a.search===r.search}catch{return!1}});let o;if(t)try{o=(await _(t,{type:"SCAN_PAGE"})).text}catch{}return o||(o=(await z(e)).text),O(o)}catch(r){return{ok:!1,error:String(r.message??r)}}}function W(e){const r=d();if(e.basic)for(const[t,o]of Object.entries(e.basic))typeof o=="string"&&o.trim()&&(r.basic[t]=o);const n=["education","experiences","publications","skills","languages","summaries"];for(const t of n){const o=e[t];Array.isArray(o)&&(r[t]=o)}return r.updatedAt=0,r}async function X(e,r){try{const n=await y(),t=await A(),o=e==="professor",s=await w(n,{system:o?G(n):B(n),messages:[{role:"user",content:o?V(t,r):F(t,r)}],json:$(n),maxTokens:4096});return{ok:!0,suggestion:P(s.text)}}catch(n){return{ok:!1,error:String(n.message??n)}}}
