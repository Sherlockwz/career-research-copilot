function e(){return{basic:{},education:[],experiences:[],publications:[],skills:[],languages:[],summaries:[],updatedAt:0}}export{e};
